package payroll.pkgclass.exceptions;


public class InvalidID extends Exception{
    public InvalidID() {
        super("ERROR: Invalid ID number");
    }
}
