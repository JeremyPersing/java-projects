
package payroll.pkgclass.exceptions;


public class InvalidName extends Exception{
    
    public InvalidName() {
        super("ERROR: Invalid Name");
    }
}
