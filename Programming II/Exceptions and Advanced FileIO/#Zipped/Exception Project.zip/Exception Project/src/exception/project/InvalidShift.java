package exception.project;


public class InvalidShift extends Exception{
    
    public InvalidShift() {
        super("ERROR: Invalid Shift.");
    }
}
