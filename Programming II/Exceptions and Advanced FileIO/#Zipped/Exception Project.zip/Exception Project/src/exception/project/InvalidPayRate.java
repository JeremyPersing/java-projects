package exception.project;


public class InvalidPayRate extends Exception{
    
    public InvalidPayRate() {
        super("ERROR: Invalid Pay Rate.");
    }
}
